package com.BraidsTribeApplication.cart;



public class CartNotFoundException extends RuntimeException {
}