package com.BraidsTribeApplication.product;

public class ProductNotFoundException extends RuntimeException {
}
